import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')
import gensim
import jieba
import numpy as np
from scipy.linalg import norm
fw = open('E:\\word2vec\\result.txt','w')
model_file=open("E:\\word2vec\\model_out.bin","r",encoding='utf-8')
model = gensim.models.KeyedVectors.load_word2vec_format(model_file, binary=True)

def vector_similarity(s1, s2):
    def sentence_vector(s):
        words = jieba.lcut(s)
        v = np.zeros(64)
        for word in words:
            v += model[word]
        v /= len(words)
        return v

    v1, v2 = sentence_vector(s1), sentence_vector(s2)
    return np.dot(v1, v2) / (norm(v1) * norm(v2))
filePath_1=open("E:\\word2vec\\patient_test1.txt","r")
filePath_2=open("E:\\word2vec\\patient_test2.txt","r")
patient_test1 = filePath_1.readlines()
patient_test2 = filePath_2.readlines()
#计算患者之间的相似度
i=1
j=1
for patient_1 in patient_test1:
    i=i+1
    for patient_2 in patient_test2:
        j=j+1
        r = vector_similarity(patient_1, patient_2)
        if r>0.8:
            fw.write('第'+ str(i) +'位患者与第'+ str(j) +'位患者的相似度是'+ str(r) +'\n')